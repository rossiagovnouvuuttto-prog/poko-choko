"""Синтез речи через локальный pyttsx3 (Windows SAPI5)"""
import pyttsx3
from config import ASSISTANT_NAME, TTS_RATE, TTS_VOLUME


class VoiceOutput:
    """Озвучивание ответов ассистента через системный TTS."""

    def __init__(self):
        self.engine = pyttsx3.init()
        self.engine.setProperty("rate", TTS_RATE)
        self.engine.setProperty("volume", TTS_VOLUME)

        # Ищем русский голос среди установленных в системе
        for voice in self.engine.getProperty("voices"):
            name = (voice.name or "").lower()
            if "russian" in name or "русск" in name or "irina" in name or "pavel" in name:
                self.engine.setProperty("voice", voice.id)
                break

    def speak(self, text: str) -> None:
        """Произнести текст."""
        print(f"[{ASSISTANT_NAME}] {text}")
        try:
            self.engine.say(text)
            self.engine.runAndWait()
        except Exception as e:
            # Если движок «застрял» (бывает при быстрых повторных вызовах) —
            # пересоздаём и пробуем ещё раз.
            print(f"[VoiceOutput] {e}")
            try:
                self.engine = pyttsx3.init()
                self.engine.setProperty("rate", TTS_RATE)
                self.engine.setProperty("volume", TTS_VOLUME)
                self.engine.say(text)
                self.engine.runAndWait()
            except Exception as e2:
                print(f"[VoiceOutput] Повтор не помог: {e2}")
